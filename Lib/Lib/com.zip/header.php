<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" media="screen" href="style.css" />
  </head>
<body class="container-fluid bg-light">
    <ul class="nav nav-tabs nav-bar-nav bg-light">
      <li class="nav-item">
        <a  class="nav-link " data-toggle="pill" href="index.php">StartNG Hospital</a>
      </li>
    </ul>
